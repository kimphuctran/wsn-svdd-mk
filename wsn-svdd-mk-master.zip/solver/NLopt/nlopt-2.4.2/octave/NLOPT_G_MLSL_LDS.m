% NLOPT_G_MLSL_LDS: Multi-level single-linkage (MLSL), quasi-random (global, needs sub-algorithm)
%
% See nlopt_minimize for more information.
function val = NLOPT_G_MLSL_LDS
  val = 39;
